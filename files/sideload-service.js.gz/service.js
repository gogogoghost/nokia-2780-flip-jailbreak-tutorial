var lib_sideload = (() => {
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

  // generated/sideload_service.js
  var sideload_service_exports = {};
  __export(sideload_service_exports, {
    Sideload: () => Sideload
  });

  // ../../../common/client/src/services.js
  var kcore = ExternalAPI.core;
  var DEBUG = false;
  var Services = {
    /**
     * Retrieves a service, returning a Promise with the service id.
     *
     * @param {string} name - the name of the service to create.
     * @param {string} fingerprint - the fingerprint of the service.
     * @param {Session} session - the service session to send function calls.
     * @return {Promise} resolve service id
     *
     */
    get: (name, fingerprint, session) => {
      DEBUG && console.log(`Services.get(${name})`);
      let buff = kcore.CoreRequest.encode({
        variant: kcore.CoreRequest.GET_SERVICE,
        name,
        fingerprint
      });
      let base_message = new kcore.BaseMessage(
        /*service*/
        0,
        /*object*/
        0,
        /*content*/
        buff
      );
      return session.send_request(base_message, kcore.CoreResponse).then((res) => {
        DEBUG && console.log(`Service.get(${name}) response: ${JSON.stringify(res)}`);
        let msg = res.msg;
        if (msg.variant === kcore.CoreRequest.GET_SERVICE && msg.response.service) {
          return msg.response.service;
        }
        return Promise.reject(msg.response.error);
      });
    },
    /**
     * Checks if the named service is available.
     *
     * @param {string} name - the name of the service to check.
     * @param {Session} session - the service session to send the call.
     * @return {Promise} resolve to true or false.
     *
     */
    has: (name, session) => {
      DEBUG && console.log(`Services.has(${name})`);
      let buff = kcore.CoreRequest.encode({
        variant: kcore.CoreRequest.HAS_SERVICE,
        name
      });
      let message = new kcore.BaseMessage(
        /*service*/
        0,
        /*object*/
        0,
        /*content*/
        buff
      );
      return session.send_request(message, kcore.CoreResponse).then((res) => {
        DEBUG && console.log(`Service.has(${name}) response: ${JSON.stringify(res)}`);
        if (res.msg.success !== void 0) {
          return res.msg.success;
        }
        return Promise.reject(`hasService failed for: ${name}`);
      });
    },
    /**
     * Creates a core message of the given kind and initial value.
     * This function performs the wrapping in a PayloadMessage message.
     *
     * @param {string} kind - the kind of functions.
     * @param {object} init_value - paramater value for the function call
     *
     */
    create_core_message: (variant, init_value) => {
      DEBUG && console.log(
        `Services create_core_message ${variant} ${JSON.stringify(init_value)}`
      );
      if (!init_value) {
        init_value = {};
      }
      init_value.variant = variant;
      return kcore.CoreRequest.encode(init_value);
    }
  };

  // ../../../common/client/src/sessionobject.js
  var kcore2 = ExternalAPI.core;
  var SessionObject = class {
    /**
     * Initialize a SessionObject object.
     * @constructor
     * @param {string} id - object id.
     * @param {Session} session - the service session to send function calls.
     * @param {object} service - the service which represents a context
     * @param {string} wrapper_payload_message - the payload message for each different
     * service.
     *
     */
    constructor(id, session, service, wrapper_payload_message) {
      this.id = id;
      this.session = session;
      this.service_id = service ? service.id : 0;
      this.wrapper_payload_message = wrapper_payload_message;
      this.event_callbacks = /* @__PURE__ */ Object.create(null);
    }
    /**
     * Send a request, and unwrap the actual expected response type.
     *
     * @param {string} message - message to be encoded.
     * @param {string} response_type - response type which is used to decode response message
     *
     */
    send_request(message, response_type) {
      return this.session.send_request(message, this.wrapper_payload_message[response_type]).then((res) => {
        let msg = res.msg;
        if (msg.success !== void 0) {
          return msg.success;
        } else {
          return Promise.reject({
            reason: "call_failure",
            value: msg.error
          });
        }
      }).catch((error) => {
        return Promise.reject(error);
      });
    }
    /**
     * Send a request that has no matching response (like member setters).
     *
     * @param {string} message - message to be encoded.
     *
     */
    send_request_oneway(message) {
      return this.session.send_request_oneway(message);
    }
    /**
     *
     * @param {object} base_message - the message to encode and send.
     */
    send_callback_message(base_message) {
      let message = new kcore2.BaseMessage(
        base_message.service,
        base_message.object,
        base_message.content
      );
      message.set_response(base_message.request);
      this.session.send_callback_message(message);
    }
    /**
     * Do function calls.
     *
     * @param {string} method_name - method name.
     * @param {object} payload - parameter for the function call
     *
     */
    call_method(method_name, payload) {
      let buff = this.create_payload_message(`${method_name}Request`, payload);
      let message = new kcore2.BaseMessage(this.service_id, this.id, buff);
      return this.send_request(message, `${method_name}Response`).then(
        (res) => {
          return res;
        },
        (error) => {
          if (error && error.reason === "call_failure") {
            const e = Object.assign({ method_name }, error);
            return Promise.reject(e);
          }
          if (error && error.reason === "permission_error") {
            const e = Object.assign({ method_name }, error);
            delete e.value.request;
            console.error(
              `Permission error in ${method_name}: missing '${e.value.permission}' - ${e.value.message}`
            );
            return Promise.reject(e);
          }
          return Promise.reject(error);
        }
      );
    }
    /**
     * Do function calls.
     *
     * @param {string} method_name - method name.
     * @param {object} payload - parameter for the function call
     *
     */
    call_method_oneway(method_name, payload) {
      let buff = this.create_payload_message(`${method_name}Request`, payload);
      let message = new kcore2.BaseMessage(this.service_id, this.id, buff);
      this.send_request_oneway(message);
    }
    /**
     * Release current object when it's no longer used.
     *
     */
    release() {
      let buff = Services.create_core_message(kcore2.CoreRequest.RELEASE_OBJECT, {
        service: this.service_id,
        object: this.id
      });
      let message = new kcore2.BaseMessage(0, 0, buff);
      return this.session.send_request(message, kcore2.CoreResponse).then((res) => {
        console.log("CoreResponse is %o", res);
        if (res.msg.variant === kcore2.CoreRequest.RELEASE_OBJECT && res.msg.success) {
          return Promise.resolve();
        }
        return Promise.reject({
          reason: "call_failure",
          value: `No such object`
        });
      });
    }
    /**
     * Enable event.
     *
     * @param {integer} event_id - event id which is defined in each service
     *
     */
    enable_event(event_id) {
      let buff = Services.create_core_message(kcore2.CoreRequest.ENABLE_EVENT, {
        service: this.service_id,
        object: this.id,
        event: event_id
      });
      let message = new kcore2.BaseMessage(0, 0, buff);
      this.session.send_request(message, kcore2.CoreResponse);
    }
    /**
     * Disable event.
     *
     * @param {integer} event_id - event id which is defined in each service
     *
     */
    disable_event(event_id) {
      let buff = Services.create_core_message(kcore2.CoreRequest.DISABLE_EVENT, {
        service: this.service_id,
        object: this.id,
        event: event_id
      });
      let message = new kcore2.BaseMessage(0, 0, buff);
      this.session.send_request(message, kcore2.CoreResponse);
    }
    /**
     * Compose a list use service_id object_id and event_id as key to store callbacks.
     *
     * @param {integer} event_id - event id which is defined in each service
     * @return {string} key - composed key
     */
    get_event_key(event_id) {
      let comma = ",";
      let key = this.service_id + comma + this.id + comma + event_id;
      return key;
    }
    /**
     * Add event listener for event of each services.
     *
     * @param {integer} event_id - event id which is defined in each service
     * @param {function} callback - function to call when event received
     *
     */
    addEventListener(event_id, callback) {
      const key = this.get_event_key(event_id);
      if (!Object.prototype.hasOwnProperty.call(this.event_callbacks, key)) {
        this.event_callbacks[key] = [];
        this.enable_event(event_id);
      } else if (this.event_callbacks[key].includes(callback)) {
        return;
      }
      this.event_callbacks[key].push(callback);
    }
    /**
     * Remove event listener for event of each services.
     *
     * @param {integer} event_id - event id which is defined in each service
     * @param {function} callback - function to stop receiving events
     *
     */
    removeEventListener(event_id, callback) {
      const key = this.get_event_key(event_id);
      if (!Object.prototype.hasOwnProperty.call(this.event_callbacks, key)) {
        return;
      }
      this.event_callbacks[key] = this.event_callbacks[key].filter(
        (element) => element !== callback
      );
      if (this.event_callbacks[key].length === 0) {
        delete this.event_callbacks[key];
        this.disable_event(event_id);
      }
    }
    /**
     * Dispatch event.
     *
     * @param {integer} event_id - event id which is defined in each service
     * @param {binary} data - the data passed to listener
     *
     */
    dispatchEvent(event_id, data) {
      const key = this.get_event_key(event_id);
      const stack = this.event_callbacks[key];
      if (stack === void 0) {
        return;
      }
      stack.forEach((element) => {
        element.call(this, data);
      });
    }
    /**
     * Create payload message based on wrapperPayloadMessage.
     * This function performs the wrapping in a wrapperPayloadMessage message
     *
     * @param {string} kind - the kind of functions.
     * @param {object} init_value - paramater value for the function call
     *
     */
    create_payload_message(variant, init_value) {
      return this.wrapper_payload_message[variant].encode(init_value || {});
    }
  };

  // ../../../common/client/src/bincode.js
  function zigzag_encode(val) {
    const i32 = 4294967296;
    let valH = Math.floor(val / i32);
    let valL = (val & 4294967295) >>> 0;
    let encodedH = valL >>> 31 ^ valH << 1 ^ valH >> 31;
    let encodedL = (valL << 1 ^ valH >> 31) >>> 0;
    return encodedH * i32 + encodedL;
  }
  function zigzag_decode(val) {
    const i32 = 4294967296;
    var valH = Math.floor(val / i32);
    var valL = (val & 4294967295) >>> 0;
    let decodedH = valH >>> 1 ^ -(valL & 1);
    let decodedL = (valH << 31 ^ valL >>> 1 ^ -(valL & 1)) >>> 0;
    return decodedH * i32 + decodedL;
  }
  var Decoder = class {
    constructor(buffer) {
      this.reset(buffer);
    }
    reset(buffer) {
      this.buffer = buffer;
      this.pos = 0;
    }
    // Throws if we decoded the whole buffer.
    throw_if_eof() {
      if (this.pos >= this.buffer.length) {
        throw Error("eof");
      }
    }
    // Throws if less than N bytes are still readable.
    throw_if_less_than(num) {
      if (this.pos + num - 1 >= this.buffer.length) {
        throw Error("eof");
      }
    }
    // Read a varint encoded integer.
    varint() {
      this.throw_if_less_than(1);
      let val = this.buffer[this.pos];
      this.pos += 1;
      if (val <= 250) {
        return val;
      }
      if (val == 251) {
        return this.full_u16();
      }
      if (val == 252) {
        return this.full_u32();
      }
      if (val == 253) {
        return this.full_u64();
      }
      if (val == 254) {
        throw Error("Failed to read varint: 128bits integers ar not supported.");
      }
      throw Error(`Failed to read varint: unexpected byte: ${val}`);
    }
    // Read a void. This is a no-op but helps with code generation using the decoder
    // since it's very common for return types.
    void() {
      return {};
    }
    // Boolean are 0u8=false 1u8=true
    bool() {
      this.throw_if_less_than(1);
      let val = this.buffer[this.pos];
      this.pos += 1;
      return val === 1;
    }
    // Strings are encoded as:
    // u64: len
    // len bytes for the ut8 encoded string.
    string() {
      let len = this.varint();
      this.throw_if_less_than(len);
      let utf8 = this.buffer.subarray(this.pos, this.pos + len);
      this.pos += len;
      let decoder = new TextDecoder("utf-8");
      return decoder.decode(utf8);
    }
    // Read a JSON representation of an object.
    json() {
      return JSON.parse(this.string());
    }
    // Read a u64
    // Note that JS range for integers is only -(2^53 - 1) .. (2^53 - 1)
    full_u64() {
      this.throw_if_less_than(8);
      let val = 0;
      for (let i = 0; i < 8; i++) {
        val = val * 256 + this.buffer[this.pos];
        this.pos += 1;
      }
      return val;
    }
    u64() {
      return this.varint();
    }
    // Read a i64
    // Note that JS range for integers is only -(2^53 - 1) .. (2^53 - 1)
    i64() {
      return zigzag_decode(this.u64());
    }
    // Read a Vec<u8> or [u8]
    u8_array() {
      let len = this.varint();
      this.throw_if_less_than(len);
      let data = this.buffer.subarray(this.pos, this.pos + len);
      this.pos += len;
      return data;
    }
    // Read a u16
    full_u16() {
      this.throw_if_less_than(2);
      let val = 0;
      for (let i = 0; i < 2; i++) {
        val = (val << 8) + this.buffer[this.pos];
        this.pos += 1;
      }
      return val;
    }
    // Read a u32
    full_u32() {
      this.throw_if_less_than(4);
      let val = 0;
      for (let i = 0; i < 4; i++) {
        val = (val << 8 >>> 0) + this.buffer[this.pos];
        this.pos += 1;
      }
      return val;
    }
    u32() {
      return this.varint();
    }
    // Read an enum tag
    enum_tag() {
      return this.varint();
    }
    // Read a Date as a i64 milliseconds since epoch
    date() {
      let date = /* @__PURE__ */ new Date();
      date.setTime(this.i64());
      return date;
    }
  };
  var Encoder = class {
    constructor() {
      this.reset();
    }
    reset() {
      this.buffer = new Uint8Array(64);
      this.size = 0;
    }
    // Extend the current buffer if needed to make sure we
    // can store num bytes.
    extend_if_needed(num) {
      if (this.buffer.length - this.size < num) {
        let new_buffer = new Uint8Array(this.size + num * 2);
        new_buffer.set(this.buffer);
        this.buffer = new_buffer;
      }
    }
    // Write a varint value.
    varint(val) {
      this.extend_if_needed(1);
      if (val <= 250) {
        this.buffer[this.size] = val;
        this.size += 1;
        return this;
      }
      if (val < 1 << 16) {
        this.buffer[this.size] = 251;
        this.size += 1;
        return this.full_u16(val);
      }
      if (val < 1 << 32) {
        this.buffer[this.size] = 252;
        this.size += 1;
        return this.full_u32(val);
      }
      this.buffer[this.size] = 253;
      this.size += 1;
      return this.full_u64(val);
    }
    // Write an enum tag
    enum_tag(val) {
      return this.varint(val);
    }
    // Write a void. This is a no-op but helps with code generation using the encoder.
    void(val) {
      return this;
    }
    // Write a u16
    full_u16(val) {
      this.extend_if_needed(2);
      this.size += 2;
      for (let i = 0; i < 2; i++) {
        this.buffer[this.size - 1 - i] = val & 255;
        val >>= 8;
      }
      return this;
    }
    // Write a u32
    full_u32(val) {
      this.extend_if_needed(4);
      this.size += 4;
      for (let i = 0; i < 4; i++) {
        this.buffer[this.size - 1 - i] = val & 255;
        val >>= 8;
      }
      return this;
    }
    // Write a u64
    full_u64(val) {
      this.extend_if_needed(8);
      this.size += 8;
      for (let i = 0; i < 8; i++) {
        this.buffer[this.size - 1 - i] = val & 255;
        val /= 256;
      }
      return this;
    }
    // Write a i64
    i64(val) {
      this.u64(zigzag_encode(val));
      return this;
    }
    u64(val) {
      this.varint(val);
      return this;
    }
    u32(val) {
      this.varint(val);
      return this;
    }
    // Write a string
    string(val) {
      let encoder = new TextEncoder();
      return this.u8_array(encoder.encode(val));
    }
    // Write an object as json, by stringifying.
    json(obj) {
      return this.string(JSON.stringify(obj));
    }
    // Write a boolean
    bool(val) {
      this.extend_if_needed(1);
      this.buffer[this.size] = !!val ? 1 : 0;
      this.size += 1;
      return this;
    }
    // Write a Vec<u8>
    u8_array(val) {
      this.varint(val.length);
      this.extend_if_needed(val.length);
      this.buffer.set(val, this.size);
      this.size += val.length;
      return this;
    }
    // Write a Date as i64 milliseconds since epoch.
    date(val) {
      this.i64(val.getTime());
      return this;
    }
    // Returns the final buffer without the trailing bytes
    // that could have been allocated when growing the buffer.
    value() {
      return this.buffer.slice(0, this.size);
    }
  };

  // generated/sideload_service.js
  var SideloadFactorySession = class extends SessionObject {
    constructor(object_id, service_id, session) {
      super(object_id, session, service_id, SideloadFactoryMessages);
      this.service_id = service_id;
    }
    getAppFile(origin, path) {
      return this.call_method("GetAppFile", {
        origin,
        path
      });
    }
    getAppManifest(manifestUrl) {
      return this.call_method("GetAppManifest", {
        manifestUrl
      });
    }
    install(packagePath) {
      return this.call_method("Install", {
        packagePath
      });
    }
    installPwa(manifestUrl) {
      return this.call_method("InstallPwa", {
        manifestUrl
      });
    }
    list() {
      return this.call_method("List", {});
    }
    ready() {
      return this.call_method("Ready", {});
    }
    uninstall(manifestUrl) {
      return this.call_method("Uninstall", {
        manifestUrl
      });
    }
  };
  var SideloadFactoryMessages = {
    GetAppFileRequest: {
      encode: (data) => {
        let encoder = new Encoder();
        let result = encoder.enum_tag(0);
        result = result.string(data.origin);
        result = result.string(data.path);
        return result.value();
      }
    },
    GetAppFileResponse: {
      decode: (buffer, service_id, session) => {
        let decoder = new Decoder(buffer);
        let variant = decoder.enum_tag();
        if (variant == 0) {
          let result = null;
          result = decoder.u8_array();
          return { success: result };
        } else if (variant == 1) {
          let result = null;
          result = decoder.string();
          return { error: result };
        } else {
          console.error(`GetAppFileResponse::decode: Unexpected variant ${variant}`);
          return null;
        }
      }
    },
    GetAppManifestRequest: {
      encode: (data) => {
        let encoder = new Encoder();
        let result = encoder.enum_tag(1);
        result = result.string(data.manifestUrl);
        return result.value();
      }
    },
    GetAppManifestResponse: {
      decode: (buffer, service_id, session) => {
        let decoder = new Decoder(buffer);
        let variant = decoder.enum_tag();
        if (variant == 2) {
          let result = null;
          result = decoder.json();
          return { success: result };
        } else if (variant == 3) {
          let result = null;
          result = decoder.string();
          return { error: result };
        } else {
          console.error(`GetAppManifestResponse::decode: Unexpected variant ${variant}`);
          return null;
        }
      }
    },
    InstallRequest: {
      encode: (data) => {
        let encoder = new Encoder();
        let result = encoder.enum_tag(2);
        result = result.string(data.packagePath);
        return result.value();
      }
    },
    InstallResponse: {
      decode: (buffer, service_id, session) => {
        let decoder = new Decoder(buffer);
        let variant = decoder.enum_tag();
        if (variant == 4) {
          let result = null;
          result = decoder.string();
          return { success: result };
        } else if (variant == 5) {
          let result = null;
          result = decoder.string();
          return { error: result };
        } else {
          console.error(`InstallResponse::decode: Unexpected variant ${variant}`);
          return null;
        }
      }
    },
    InstallPwaRequest: {
      encode: (data) => {
        let encoder = new Encoder();
        let result = encoder.enum_tag(3);
        result = result.string(data.manifestUrl);
        return result.value();
      }
    },
    InstallPwaResponse: {
      decode: (buffer, service_id, session) => {
        let decoder = new Decoder(buffer);
        let variant = decoder.enum_tag();
        if (variant == 6) {
          let result = null;
          result = decoder.string();
          return { success: result };
        } else if (variant == 7) {
          let result = null;
          result = decoder.string();
          return { error: result };
        } else {
          console.error(`InstallPwaResponse::decode: Unexpected variant ${variant}`);
          return null;
        }
      }
    },
    ListRequest: {
      encode: (data) => {
        let encoder = new Encoder();
        let result = encoder.enum_tag(4);
        return result.value();
      }
    },
    ListResponse: {
      decode: (buffer, service_id, session) => {
        let decoder = new Decoder(buffer);
        let variant = decoder.enum_tag();
        if (variant == 8) {
          let result = null;
          result = decoder.json();
          return { success: result };
        } else if (variant == 9) {
          let result = null;
          result = decoder.string();
          return { error: result };
        } else {
          console.error(`ListResponse::decode: Unexpected variant ${variant}`);
          return null;
        }
      }
    },
    ReadyRequest: {
      encode: (data) => {
        let encoder = new Encoder();
        let result = encoder.enum_tag(5);
        return result.value();
      }
    },
    ReadyResponse: {
      decode: (buffer, service_id, session) => {
        let decoder = new Decoder(buffer);
        let variant = decoder.enum_tag();
        if (variant == 10) {
          let result = null;
          result = decoder.bool();
          return { success: result };
        } else if (variant == 11) {
          let result = null;
          result = decoder.void();
          return { error: result };
        } else {
          console.error(`ReadyResponse::decode: Unexpected variant ${variant}`);
          return null;
        }
      }
    },
    UninstallRequest: {
      encode: (data) => {
        let encoder = new Encoder();
        let result = encoder.enum_tag(6);
        result = result.string(data.manifestUrl);
        return result.value();
      }
    },
    UninstallResponse: {
      decode: (buffer, service_id, session) => {
        let decoder = new Decoder(buffer);
        let variant = decoder.enum_tag();
        if (variant == 12) {
          let result = null;
          result = decoder.string();
          return { success: result };
        } else if (variant == 13) {
          let result = null;
          result = decoder.string();
          return { error: result };
        } else {
          console.error(`UninstallResponse::decode: Unexpected variant ${variant}`);
          return null;
        }
      }
    }
  };
  var Sideload = {
    get: (session) => {
      return Services.get("Sideload", "616bd92fde967a82d1de56883afab0d36a8ed9cb344bde0954219a53aaea4fb", session).then((service_id) => {
        return new SideloadFactorySession(0, service_id, session);
      });
    }
  };
  return __toCommonJS(sideload_service_exports);
})();
